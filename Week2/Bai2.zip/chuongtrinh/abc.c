#include <stdio.h>
void abc()
{
    printf("Hello\n");
}